package algoritmoEuclidesRamosRuizPedroMugnozCordonEstela;

/**
 * Adem&aacute;s de los c&oacute;digos generados, en un fichero &quot;PruebaCaminoBasicoEuclidesNombreApellido1Apellido2.pdf&quot; 
 * documenta todo el proceso de la forma m&aacute;s did&aacute;ctica posible, indicando en distintos apartados:
 * <ol>
 * 	<li>Pruebas del camino b&aacute;sico.</li>
 * 		<ul>
 * 			<li>Grafo de flujo del m&eacute;todo. Puedes utilizar herramientas online para la creaci&oacute;n de grafos.</li>
 * 			<li>Complejidad ciclom&aacute;tica. Detalla la f&oacute;rmula para su c&aacute;lculo.</li>
 *      	<li>Conjunto b&aacute;sico de caminos independientes.</li>
 *      	<li>Casos de prueba. Distintos al del documento pdf.</li>
 *  	</ul>
 *  <li>Coverage tools. Herramientas para Eclipse. JUnit y Eclemma</li>
 *      <ul>
 *      	<li>JUnit.
 *      		Para realizar las pruebas genera el m&eacute;todo testEuclides. Incluye ah&iacute; los caminos independientes.</li>
 *        	<li>Eclemma.
 *             	Una vez definidas las pruebas, confirma la cobertura al 100%. 
 *             	En el di&aacute;logo &quot;Coverage configuration...&quot; indica los test a probar. 
 *              Demu&eacute;stralo con pantallazos de c&oacute;digo en verde y distintos contadores al 100%</li>
 *      </ul>
 * </ol>         	
 * 
 * @author Estela Mu&ntilde;oz
 * @author Pedro J. Ramos
 * @version 1.0
 *
 */

public class Matematicas {
	
    /**
     * Devuelve el m&aacute;ximo com&uacute;n divisor de dos n&uacute;meros
     * 
     * @param a N&uacute;mero para hallar el MCD
     * @param b N&uacute;mero para hallar el MCD
     * @return M&aacute;ximo com&uacute;n divisor de los dos n&uacute;meros
     */
    static int euclides(int a, int b) {
        if (a < b) {
            int tmp = a;
            a = b;
            b = tmp;
        }
        int resto;
        // Ahora en a estar� el mayor
        while ((resto = a % b) != 0) {
            a = b;
            b = resto;
        }
        return b;
    }
}