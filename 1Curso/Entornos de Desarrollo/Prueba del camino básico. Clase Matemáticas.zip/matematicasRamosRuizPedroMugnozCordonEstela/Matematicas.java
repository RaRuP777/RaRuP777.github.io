package matematicasRamosRuizPedroMugnozCordonEstela;

/**
 * Ampl&iacute;a la clase Matematicas con los siguientes m&eacute;todos. 
 * Para cada uno de ellos dise&ntilde;a el conjunto de casos de prueba mediante la t&eacute;cnica del camino b&aacute;sico:
 * <ul>
 * 	<li>static int menorDeTres(int a, int b, int c) {},</li>
 * 	<li>static Respuesta positivoNegativoCero(int numero) {},</li>
 * </ul>
 * static boolean esPar(int a) {}
 * En Eclemma, dentro de la vista de cobertura existen seis m&eacute;tricas distintas que eval&eacute;an la cobertura. 
 * Indica qu&eacute; representan cada una de ellas y confirma que todas se cubren al 100%:
 * <ol>
 * 	<li>instrucciones,</li>
 * 	<li>ramas,</li>
 * 	<li>l&iacute;neas con tres colores,</li>
 * 	<li>complejidad ciclom&aacute;tica,</li>
 * 	<li>m&eacute;todos y</li>
 * 	<li>clases</li>
 * </ol>
 * 
 * @author Estela Mu&ntilde;oz
 * @author Pedro J. Ramos
 * @version 1.0
 *
 */

public class Matematicas {
	
    /**
     * Devuelve el m�ximo com�n divisor de dos n�meros
     * 
     * @param a
     *            n�mero para hallar el MCD
     * @param b
     *            n�mero para hallar el MCD
     * @return M�ximo com�n divisor de los dos n�meros
     */
    static int euclides(int a, int b) {
        if (a < b) {
            int tmp = a;
            a = b;
            b = tmp;
        }
        int resto;
        // Ahora en a estar� el mayor
        while ((resto = a % b) != 0) {
            a = b;
            b = resto;
        }
        return b;
    }
    
    /**
     * Comprueba cu&aacute;l es el menor de tres n&uacute;meros
     * 
     * @param a Primer n&uacute;mero
     * @param b Segundo n&uacute;mero
     * @param c Tercer n&uacute;mero
     * @return El menor de los tres n&uacute;mero
     */
    static int menorDeTres(int a, int b, int c){
    	if(a<b && a<c)
    		return a;
    	else if(b<a && b<c)
    		return b;
    	else
    		return c;
    }
    
    /**
     * Comprueba si un n&uacute;mero es positivo, negativo o cero
     * 
     * @param numero N&uacute;mero introducido por teclado
     * @return Responde si el n&uacute;mero es positivo, negativo o cero
     */
    static Respuesta positivoNegativoCero(int numero){
    	if (numero>0)
    		return Respuesta.POSITIVO;
    	else if (numero<0)
    		return Respuesta.NEGATIVO;
    	else
    		return Respuesta.CERO;
    }
    
    /**
     * Comprueba si un n&uacute;mero es par o impar
     * 
     * @param a N&uacute;mero a comparar
     * @return True si es par y False sino
     */
    static boolean esPar(int a){
    	if(a % 2 ==0)
    		return true;
    	else
    		return false;
    }
}