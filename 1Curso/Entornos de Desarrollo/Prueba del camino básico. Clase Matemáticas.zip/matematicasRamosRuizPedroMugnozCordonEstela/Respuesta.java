package matematicasRamosRuizPedroMugnozCordonEstela;

public enum Respuesta {
	/**
	 * N&uacute;mero positivo
	 */
	POSITIVO, 
	/**
	 * N&uacute;mero negativo
	 */
	NEGATIVO, 
	/**
	 * N&uacute;mero cero
	 */
	CERO;
}
