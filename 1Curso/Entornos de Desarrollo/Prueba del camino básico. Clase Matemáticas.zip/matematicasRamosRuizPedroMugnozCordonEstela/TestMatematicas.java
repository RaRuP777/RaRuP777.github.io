package matematicasRamosRuizPedroMugnozCordonEstela;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Test;

/**
 * Ampl&iacute;a la clase Matematicas con los siguientes m&eacute;todos. 
 * Para cada uno de ellos dise&ntilde;a el conjunto de casos de prueba mediante la t&eacute;cnica del camino b&aacute;sico:
 * <ul>
 * 	<li>static int menorDeTres(int a, int b, int c) {},</li>
 * 	<li>static Respuesta positivoNegativoCero(int numero) {},</li>
 * </ul>
 * static boolean esPar(int a) {}
 * En Eclemma, dentro de la vista de cobertura existen seis m&eacute;tricas distintas que eval&eacute;an la cobertura. 
 * Indica qu&eacute; representan cada una de ellas y confirma que todas se cubren al 100%:
 * <ol>
 * 	<li>instrucciones,</li>
 * 	<li>ramas,</li>
 * 	<li>l&iacute;neas con tres colores,</li>
 * 	<li>complejidad ciclom&aacute;tica,</li>
 * 	<li>m&eacute;todos y</li>
 * 	<li>clases</li>
 * </ol>
 * 
 * @author Estela Mu&ntilde;oz
 * @author Pedro J. Ramos
 * @version 1.0
 *
 */

public class TestMatematicas {

	@Test
	public void test() {
		Matematicas.euclides(4,20);
	}
	
	@Test
	public void test2() {
		Matematicas.euclides(20,4);
	}
	
	@Test
	public void test3() {
		Matematicas.euclides(20,15);
	}
	
	@Test
	public void testMenorEsA(){
		Matematicas.menorDeTres(2, 3, 5);	
	}
	
	@Test
	public void testMenorEsB(){
		Matematicas.menorDeTres(5, 2, 3);	
	}
	
	@Test
	public void testMenorEsC(){
		Matematicas.menorDeTres(3, 5, 2);	
	}
	
	@Test
	public void testPositivo(){
		Matematicas.positivoNegativoCero(2);
	}
	
	@Test
	public void testNegativo(){
		Matematicas.positivoNegativoCero(-2);
	}
	
	@Test
	public void testCero(){
		Matematicas.positivoNegativoCero(0);
	}
	
	@Test
	public void testPar(){
		Matematicas.esPar(2);
	}
	
	@Test
	public void testImpar(){
		Matematicas.esPar(3);
	}

}
